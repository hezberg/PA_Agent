"""BacktestEngine — orchestrate vectorized execution pipeline.

Coordinates Strategy → OrderSimulator → PortfolioTracker → PerformanceAnalyzer.

信号生成双路径（v1.28）：

- **向量化快速路径**：策略实现了
  :meth:`~easy_tdx.backtest.strategy.Strategy.entry_exit_masks` 且无缠论注入时，
  预计算指标列后用 numpy 掩码 + 事件 bar 状态机一次性产出信号（逐 bar 的
  Python 循环是网格寻优的实测瓶颈，见 CHANGELOG v1.25 的诚实数据）；
- **逐 bar 路径**：不满足约束时自动回退，行为与历史版本完全一致。

两条路径在同一 df + 同参数下 performance 逐位一致（对拍单测守护，
``tests/unit/test_backtest_engine_vector.py``）。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import numpy as np
import pandas as pd

from easy_tdx.backtest.orders import OrderSimulator
from easy_tdx.backtest.performance import PerformanceAnalyzer
from easy_tdx.backtest.portfolio import PortfolioTracker
from easy_tdx.backtest.strategy import Strategy
from easy_tdx.backtest.types import BacktestResult, Signal, Trade

if TYPE_CHECKING:
    from easy_tdx.backtest.execution import ExecutionModel
    from easy_tdx.backtest.slippage import SlippageModel


@dataclass
class _StopCondition:
    """Active stop-loss / take-profit condition tied to an open position.

    三条退出线构成 OCO：任一触发即整体失效（见 ``_check_stop_conditions``）。

    Attributes:
        stop_loss: Price below which a SELL is triggered (None = disabled)
        take_profit: Price above which a SELL is triggered (None = disabled)
        trail_stop: Trailing stop percent (e.g. 0.08 = 8% below the highest
            close since entry, None = disabled). Fixed ``stop_loss`` wins when
            both are set.
        high_watermark: Highest close seen since the BUY (trailing reference).
            Updated at the END of each bar (after the trigger check), so a
            trailing stop can only fire from the NEXT bar onward — consistent
            with next_open execution semantics.
    """

    stop_loss: float | None
    take_profit: float | None
    trail_stop: float | None = None
    high_watermark: float = 0.0

    def effective_stop(self) -> float | None:
        """当前生效的止损价（固定价优先，其次移动止损；均无则 None）。"""
        if self.stop_loss is not None:
            return self.stop_loss
        if self.trail_stop is not None:
            return self.high_watermark * (1.0 - self.trail_stop)
        return None


class BacktestEngine:
    """Orchestrate backtest execution pipeline.

    Pipeline:
        1. Signal generation (Strategy)
        2. Order simulation (OrderSimulator)
        3. Portfolio tracking (PortfolioTracker)
        4. Performance analysis (PerformanceAnalyzer)

    Example:
        >>> engine = BacktestEngine(MyStrategy, cash=100000)
        >>> result = engine.run(df)
    """

    def __init__(
        self,
        strategy: type[Strategy] | Strategy,
        cash: float = 100000.0,
        commission: float = 0.0003,
        min_commission: float = 5.0,
        stamp_tax: float = 0.001,
        slippage: float = 0.0,
        execution: str = "next_open",
        position_mode: str = "full",
        reject_policy: str = "reduce",
        benchmark: pd.DataFrame | None = None,
        chanlun_level: str | None = None,
        slippage_model: SlippageModel | None = None,
        execution_model: ExecutionModel | None = None,
        warmup_bars: int = 0,
        symbol: str | None = None,
        auto_fees: bool = False,
        indicator_cache: Any | None = None,
        signal_path: str = "auto",
    ):
        """Initialize engine.

        Args:
            strategy: Strategy class or instance
            cash: Initial cash
            commission: Commission rate (e.g., 0.0003 = 0.03%)
            min_commission: Minimum commission per trade
            stamp_tax: Stamp tax rate (for sells)
            slippage: Slippage rate
            execution: Execution mode ('next_open', 'next_close')
            position_mode: Position mode ('full', 'long_only', 'short_only')
            reject_policy: Reject policy ('reduce', 'reject')
            benchmark: Benchmark data for performance comparison
            chanlun_level: Auto-compute chanlun analysis at this level
                (e.g. 'DAILY', '30MIN'). Strategy accesses via self.chanlun.
            slippage_model: Pluggable slippage model (overrides flat slippage
                when provided).
            execution_model: Pluggable execution model (bypasses OrderSimulator
                when provided).
            warmup_bars: 指标预热 bar 数。前 ``warmup_bars`` 根不调用
                ``next()``、不产生信号（指标 NaN 期过滤），避免早期数据不足
                导致的越界或误信号。默认 0（向后兼容）。
            symbol: 标的代码（如 ``"SH:510300"``，供品种感知费率解析）。
            auto_fees: 为 True 且提供 symbol 时，按品种自动解析
                commission/min_commission/stamp_tax（ETF/债券免印花税等），
                覆盖默认值；显式传入的非默认费率仍优先于自动解析。
            indicator_cache: 指标计算缓存（网格寻优跨点复用，见
                :class:`~easy_tdx.backtest.indicator_cache.IndicatorCache`）。
                None = 每次直接计算（默认，向后兼容）。
            signal_path: 信号生成路径。``"auto"``（默认）= 策略满足向量化约束
                时走快速路径、否则回退逐 bar；``"vector"`` = 强制向量化
                （不满足约束时抛 ValueError，测试/基准用）；``"loop"`` = 强制
                逐 bar（对拍基准用）。两条路径结果逐位一致（对拍单测守护）。

        .. versionchanged:: 1.24
            新增 ``symbol`` / ``auto_fees`` 品种感知费率参数。
        .. versionchanged:: 1.28
            新增 ``signal_path`` 与向量化快速路径（约束见
            :meth:`~easy_tdx.backtest.strategy.Strategy.entry_exit_masks`）。
        """
        self._strategy_cls = strategy if isinstance(strategy, type) else type(strategy)
        self._strategy_instance = strategy if isinstance(strategy, Strategy) else None

        self._symbol = symbol
        if auto_fees and symbol:
            from easy_tdx.backtest.fees import resolve_fee_model

            fee = resolve_fee_model(symbol)
            # 显式非默认值优先（调用方有意覆盖），否则用品种默认
            if commission == 0.0003:
                commission = fee.commission
            if min_commission == 5.0:
                min_commission = fee.min_commission
            if stamp_tax == 0.001:
                stamp_tax = fee.stamp_tax

        self._cash = cash
        self._commission = commission
        self._min_commission = min_commission
        self._stamp_tax = stamp_tax
        self._slippage = slippage
        self._execution = execution
        self._position_mode = position_mode
        self._reject_policy = reject_policy
        self._benchmark = benchmark
        self._chanlun_level = chanlun_level
        self._slippage_model = slippage_model
        self._execution_model = execution_model
        self._warmup_bars = max(int(warmup_bars), 0)
        self._indicator_cache = indicator_cache
        if signal_path not in ("auto", "vector", "loop"):
            raise ValueError(f"signal_path 取值应为 auto/vector/loop，得到 '{signal_path}'")
        self._signal_path = signal_path

    def run(self, df: pd.DataFrame, chanlun_result: Any | None = None) -> BacktestResult:
        """Run backtest.

        Args:
            df: Price data with OHLCV columns
            chanlun_result: Optional chanlun analysis result for strategy.
                When provided, takes priority over auto-computed result.

        Returns:
            BacktestResult with performance, equity_curve, trades, positions, config
        """
        if len(df) == 0:
            return self._empty_result()

        # 兼容真实行情日线数据：get_security_bars 日线返回 date 列，引擎内部
        # （StrategyDataProxy / PortfolioTracker / _find_bar_index）统一使用
        # datetime 列。缺则由 date 派生，避免上层手动重命名。
        if "datetime" not in df.columns and "date" in df.columns:
            df = df.copy()
            df["datetime"] = df["date"]

        # Auto-compute chanlun if chanlun_level is set and no manual result
        if chanlun_result is None and self._chanlun_level is not None:
            from easy_tdx.chanlun.analyser import ChanlunAnalyser

            analyser = ChanlunAnalyser(frequency=self._chanlun_level)
            chanlun_result = analyser.process_klines(df)

        # Step 1: Signal generation
        signals = self._generate_signals(df, chanlun_result)

        # Step 2: Order simulation
        if self._execution_model is not None:
            # ExecutionModel path
            trades = self._execute_with_model(signals, df)
        else:
            # OrderSimulator path (default)
            simulator = OrderSimulator(
                df,
                execution=self._execution,
                position_mode=self._position_mode,
                reject_policy=self._reject_policy,
                commission=self._commission,
                min_commission=self._min_commission,
                stamp_tax=self._stamp_tax,
                slippage=self._slippage,
                slippage_model=self._slippage_model,
            )
            trades = simulator.simulate(
                signals=signals,
                cash=self._cash,
                position=0.0,
            )

        # Step 3: Portfolio tracking
        trades = self._compute_pnls(trades)
        tracker = PortfolioTracker(df, initial_cash=self._cash)
        tracker.apply_trades(trades)

        # Step 4: Performance analysis
        trades_df = self._trades_to_df(trades)
        analyzer = PerformanceAnalyzer(
            tracker.equity_curve,
            trades_df,
            risk_free_rate=0.03,
        )
        performance = analyzer.compute()

        # Config snapshot
        config: dict[str, Any] = {
            "cash": self._cash,
            "commission": self._commission,
            "min_commission": self._min_commission,
            "stamp_tax": self._stamp_tax,
            "execution": self._execution,
            "position_mode": self._position_mode,
            "reject_policy": self._reject_policy,
        }
        if self._symbol:
            config["symbol"] = self._symbol

        return BacktestResult(
            performance=performance,
            equity_curve=tracker.equity_curve,
            trades=trades_df,
            positions=tracker.positions,
            config=config,
            diagnostic=analyzer.diagnostic,
        )

    def _execute_with_model(self, signals: list[Signal], df: pd.DataFrame) -> list[Trade]:
        """Use ExecutionModel to process signals."""
        assert self._execution_model is not None
        all_trades: list[Trade] = []
        cash = self._cash
        position = 0.0

        for signal in signals:
            bar_idx = self._find_bar_index(df, signal.datetime)
            if bar_idx is None:
                continue
            sub_trades = self._execution_model.execute(
                signal=signal,
                df=df,
                bar_idx=bar_idx,
                cash=cash,
                position=position,
                position_mode=self._position_mode,
                commission=self._commission,
                min_commission=self._min_commission,
                stamp_tax=self._stamp_tax,
                slippage_model=self._slippage_model,
            )
            for t in sub_trades:
                if not t.rejected:
                    if t.direction == "BUY":
                        cash -= t.size * t.price + t.commission + t.slippage
                        position += t.size
                    else:
                        cash += t.size * t.price - t.commission - t.slippage
                        position -= t.size
            all_trades.extend(sub_trades)
        return all_trades

    @staticmethod
    def _find_bar_index(df: pd.DataFrame, datetime_val: int) -> int | None:
        """Find bar index by datetime value."""
        dt_col = df["datetime"]
        try:
            idx = (dt_col == datetime_val).idxmax() if (dt_col == datetime_val).any() else None
            if idx is not None:
                return int(idx)
        except (TypeError, ValueError):
            pass
        if hasattr(dt_col, "dt"):
            dt_ints = dt_col.dt.strftime("%Y%m%d").astype(int)
            mask = dt_ints == datetime_val
            if mask.any():
                return int(mask.idxmax())
        return None

    def _generate_signals(self, df: pd.DataFrame, chanlun_result: Any | None) -> list[Signal]:
        """Generate signals from strategy.

        After each bar's signals, update strategy's internal position state so
        subsequent bars can make informed decisions (e.g., "don't buy if already
        holding"). Uses close price as estimate; actual execution price is
        determined later by OrderSimulator.

        Args:
            df: Price data
            chanlun_result: Optional chanlun analysis result

        Returns:
            List of signals
        """
        # Instantiate strategy if needed
        strat = (
            self._strategy_instance if self._strategy_instance is not None else self._strategy_cls()
        )

        # Bind data
        strat._bind_data(df)
        # 挂载指标缓存（两段式寻优加速；None 时 I() 直接计算）
        strat._indicator_cache = self._indicator_cache

        # Inject chanlun result if provided
        if chanlun_result is not None:
            strat._chanlun_result = chanlun_result

        # Initialize position tracking
        strat._cash = self._cash
        strat._position_size = 0.0
        close_arr = df["close"].to_numpy()

        # Call init
        strat._call_init()

        # ── 向量化快速路径（v1.28）：满足约束时跳过逐 bar 循环 ──────────────
        if self._signal_path in ("auto", "vector"):
            eligible, reason = self._vectorize_eligibility(strat, chanlun_result)
            if eligible:
                signals = self._generate_signals_vector(df, strat)
                if signals is not None:
                    return signals
                reason = "entry_exit_masks 形状与 K 线长度不符"
            if self._signal_path == "vector":
                raise ValueError(f"策略不满足向量化约束：{reason}")
            # auto：回退逐 bar 路径（行为与历史版本一致）

        # ── 逐 bar 路径（历史行为，逐字未动） ───────────────────────────────
        all_signals: list[Signal] = []
        active_stops: list[_StopCondition] = []

        high_arr = df["high"].to_numpy()
        low_arr = df["low"].to_numpy()

        for i in range(len(df)):
            strat._set_bar_index(i)

            # warmup 期（指标 NaN 预热）不调用 next()、不产生信号，但仍推进
            # bar_index 与后续 PortfolioTracker 的资金曲线对齐。
            if i < self._warmup_bars:
                continue

            strat._call_next()
            bar_signals = strat._clear_signals()

            # Check existing SL/TP conditions against current bar's price range
            sl_tp_signals = self._check_stop_conditions(
                active_stops, high_arr[i], low_arr[i], close_arr[i], i, df
            )

            # Combine strategy signals with SL/TP signals
            combined = bar_signals + sl_tp_signals

            # Register new SL/TP from BUY signals (after checking, so they
            # activate on the NEXT bar — consistent with next_open execution)
            for sig in bar_signals:
                if sig.direction == "BUY" and (
                    sig.stop_loss is not None
                    or sig.take_profit is not None
                    or sig.trail_stop is not None
                ):
                    active_stops.append(
                        _StopCondition(
                            stop_loss=sig.stop_loss,
                            take_profit=sig.take_profit,
                            trail_stop=sig.trail_stop,
                            high_watermark=close_arr[i],
                        )
                    )

            # Clear conditions when a SELL occurs (strategy or SL/TP triggered)
            for sig in combined:
                if sig.direction == "SELL" and active_stops:
                    active_stops.clear()

            # Update strategy position state so next bar sees current holdings
            self._update_strategy_position(strat, combined, close_arr[i])

            all_signals.extend(combined)

        return all_signals

    # ── 向量化快速路径（v1.28） ────────────────────────────────────────────────

    def _vectorize_eligibility(
        self, strat: Strategy, chanlun_result: Any | None
    ) -> tuple[bool, str]:
        """显式约束检测：策略 + 引擎配置是否可走向量化路径。

        约束（可测试，见 test_backtest_engine_vector.py）：
        1. 策略覆写了 ``entry_exit_masks``（显式声明语义等价的掩码）；
        2. 无缠论注入（``chanlun_result`` / ``chanlun_level`` 都未设置——
           缠论策略的 next() 依赖缠论结果，掩码无法表达）。

        Returns:
            (是否可向量化, 不可用原因描述)。
        """
        if type(strat).entry_exit_masks is Strategy.entry_exit_masks:
            return False, "策略未实现 entry_exit_masks"
        if chanlun_result is not None or self._chanlun_level is not None:
            return False, "缠论注入（chanlun_result/chanlun_level）不支持向量化"
        return True, ""

    def _generate_signals_vector(self, df: pd.DataFrame, strat: Strategy) -> list[Signal] | None:
        """用 entry/exit 掩码 + 事件 bar 状态机一次性产出信号。

        状态机语义与逐 bar 路径严格对齐（对拍单测守护逐位一致）：

        - 空仓 + ``entry[i]`` → 全仓 BUY（与 ``buy()`` 同参：size=0、无限价、
          无止损止盈）；
        - 持仓 + ``exit[i]`` → 全仓 SELL；
        - 持仓估算复刻 :meth:`_update_strategy_position`：按收盘价全仓、
          100 股整手、资金不足 1 手时仓位状态不变（后续 entry 仍可触发）；
        - warmup 期不产生信号。

        Returns:
            信号列表；掩码形状与 K 线不符（策略实现错误）返回 None 供上层回退。
        """
        masks = strat.entry_exit_masks()
        if masks is None:
            return None
        entry_raw, exit_raw = masks
        entry = np.asarray(entry_raw, dtype=bool)
        exit_ = np.asarray(exit_raw, dtype=bool)
        n = len(df)
        if entry.ndim != 1 or exit_.ndim != 1 or len(entry) != n or len(exit_) != n:
            return None

        dt_arr = strat._datetime_array
        close_arr = df["close"].to_numpy(dtype=np.float64)
        if dt_arr is None:
            return None

        # 候选事件 bar（任一掩码触发），远少于总 bar 数——逐 bar 循环退化为
        # 逐事件循环，这是向量化收益的来源
        candidates = np.flatnonzero(entry | exit_)
        candidates = candidates[candidates >= self._warmup_bars]

        signals: list[Signal] = []
        cash = self._cash
        position = 0.0

        for i in candidates:
            i_int = int(i)
            if position == 0.0 and entry[i_int]:
                signals.append(
                    Signal(datetime=int(dt_arr[i_int]), direction="BUY", size=0, price=None)
                )
                price = close_arr[i_int]
                shares = int(cash / (price * (1 + self._commission)) / 100) * 100
                if shares > 0:
                    position += shares
                    cash -= shares * price
            elif position > 0.0 and exit_[i_int]:
                signals.append(
                    Signal(datetime=int(dt_arr[i_int]), direction="SELL", size=0, price=None)
                )
                cash += position * close_arr[i_int]
                position = 0.0

        # 保持策略内部状态与逐 bar 路径一致（后续读取 strat._cash 的代码同构）
        strat._cash = cash
        strat._position_size = position
        return signals

    def _check_stop_conditions(
        self,
        active_stops: list[_StopCondition],
        bar_high: float,
        bar_low: float,
        bar_close: float,
        bar_index: int,
        df: pd.DataFrame,
    ) -> list[Signal]:
        """Check active SL/TP conditions against current bar's price range.

        If triggered, generates a SELL signal at the trigger price and removes
        the condition (OCO: all remaining legs of the same condition die too).
        Stop-loss is checked first (conservative: assume the worst case for
        the holder). Trailing stops reference the highest close seen through
        the PREVIOUS bar (watermark is updated after the check), so they can
        never fire on the same bar that sets a new high.

        Args:
            active_stops: List of active stop conditions
            bar_high: Current bar's high price
            bar_low: Current bar's low price
            bar_close: Current bar's close price
            bar_index: Current bar index
            df: Price DataFrame (for datetime extraction)

        Returns:
            List of SELL signals triggered by SL/TP conditions
        """
        if not active_stops:
            return []

        signals: list[Signal] = []
        remaining: list[_StopCondition] = []

        for cond in active_stops:
            triggered = False
            trigger_price = 0.0

            # Check stop-loss first (worst case for holder); trailing resolves
            # to its effective price, fixed stop_loss wins if both set
            eff_stop = cond.effective_stop()
            if eff_stop is not None and bar_low <= eff_stop:
                triggered = True
                trigger_price = eff_stop
            # Then check take-profit
            elif cond.take_profit is not None and bar_high >= cond.take_profit:
                triggered = True
                trigger_price = cond.take_profit

            if not triggered:
                # Trailing watermark update AFTER the check (close-based)
                cond.high_watermark = max(cond.high_watermark, bar_close)
                remaining.append(cond)
            else:
                # Get datetime for this bar
                dt_val = df["datetime"].iloc[bar_index]
                if hasattr(dt_val, "strftime"):
                    dt_int = int(dt_val.strftime("%Y%m%d"))
                else:
                    dt_int = int(dt_val)

                signals.append(
                    Signal(
                        datetime=dt_int,
                        direction="SELL",
                        size=0,  # full position close
                        price=trigger_price,
                        source="stop",  # 标记为止损/止盈触发，延迟到下一根成交
                    )
                )

        active_stops.clear()
        active_stops.extend(remaining)
        return signals

    def _update_strategy_position(
        self, strat: Strategy, signals: list[Signal], est_price: float
    ) -> None:
        """Update strategy's internal position estimate after each bar.

        Uses close price as estimate for full-position calculations.
        The actual execution price is determined by OrderSimulator later.

        Args:
            strat: Strategy instance
            signals: Signals generated on this bar
            est_price: Estimated price (close of current bar)
        """
        for sig in signals:
            price = sig.price or est_price
            if sig.direction == "BUY":
                if sig.size == 0:
                    # Full position: estimate shares (100-lot rounding)
                    shares = int(strat._cash / (price * (1 + self._commission)) / 100) * 100
                    if shares > 0:
                        strat._position_size += shares
                        strat._cash -= shares * price
                else:
                    strat._position_size += sig.size
                    strat._cash -= sig.size * price
            elif sig.direction == "SELL":
                if sig.size == 0:
                    # Full sell
                    strat._cash += strat._position_size * price
                    strat._position_size = 0.0
                else:
                    strat._cash += sig.size * price
                    strat._position_size = max(0.0, strat._position_size - sig.size)

    def _compute_pnls(self, trades: list[Trade]) -> list[Trade]:
        """Compute realized PnL for sell trades.

        Args:
            trades: List of trades

        Returns:
            Trades with PnL computed
        """
        position_cost = 0.0
        position_size = 0.0

        for trade in trades:
            if not trade.rejected:
                if trade.direction == "BUY":
                    position_cost += trade.size * trade.price + trade.commission
                    position_size += trade.size
                    trade.pnl = 0.0
                elif trade.direction == "SELL":
                    if position_size > 0:
                        avg_cost = position_cost / position_size
                        trade.pnl = (trade.price - avg_cost) * trade.size - trade.commission
                        # 记录本次卖出对应的持仓成本基数，用于派生单笔收益率
                        trade.cost_basis = avg_cost * trade.size
                        position_cost -= avg_cost * trade.size
                        position_size -= trade.size
                    else:
                        trade.pnl = 0.0

        return trades

    def _trades_to_df(self, trades: list[Trade]) -> pd.DataFrame:
        """Convert trades to DataFrame.

        Args:
            trades: List of trades

        Returns:
            DataFrame with trade data
        """
        if not trades:
            return pd.DataFrame(
                columns=[
                    "datetime",
                    "direction",
                    "size",
                    "price",
                    "commission",
                    "slippage",
                    "pnl",
                    "cost_basis",
                    "rejected",
                ]
            )

        data = [
            {
                "datetime": t.datetime,
                "direction": t.direction,
                "size": t.size,
                "price": t.price,
                "commission": t.commission,
                "slippage": t.slippage,
                "pnl": t.pnl,
                "cost_basis": t.cost_basis,
                "rejected": t.rejected,
            }
            for t in trades
        ]
        return pd.DataFrame(data)

    def _empty_result(self) -> BacktestResult:
        """Return empty result for empty input.

        Returns:
            BacktestResult with empty DataFrames
        """
        analyzer = PerformanceAnalyzer(
            pd.DataFrame(columns=["total", "drawdown", "drawdown_pct"]),
            pd.DataFrame(columns=["direction", "pnl", "rejected"]),
        )
        perf = analyzer.compute()

        return BacktestResult(
            performance=perf,
            equity_curve=pd.DataFrame(
                columns=["datetime", "cash", "position_value", "total", "drawdown", "drawdown_pct"]
            ),
            trades=pd.DataFrame(
                columns=[
                    "datetime",
                    "direction",
                    "size",
                    "price",
                    "commission",
                    "slippage",
                    "pnl",
                    "rejected",
                ]
            ),
            positions=pd.DataFrame(
                columns=["datetime", "size", "avg_price", "market_value", "unrealized_pnl"]
            ),
            config={},
            diagnostic=analyzer.diagnostic,
        )
